
<?php

//Books*
$catalog[101] = [
"title" => "Beloved"
"img" => "../img/media/beloved.jpg",
   "genre" => "Magical Realism",
   "format" => "Paperback",
   "year" => "1987",
   "category" => "Books",
   "authors" => [
       "Toni Morrison",
   ],
   "publisher" => "Alfred A Knopf",
   "isbn" => '9780099273936',

];

  $catalog[102] = [ 
  "title" => "The Great Gatsby",
  "img" => "../img/media/great-gatsby.jpg",
  "genre" => "Fiction",
  "format" => "Paperback",
  "year" => "1925",
  "category" => "Books",
  "authors" =>  [
  "F. Scott Fitzgerald",

 ],
 "publisher" => "Scribner",
 "isbn" => "9780743273565",

]; 

  $catalog[103] = [ 
  "title" => "It",
  "img" => "../img/media/it.jpg",
  "genre" => "Horror",
  "format" => "Paperback",
  "year" => "1986",
  "category" => "Books",
  "authors" => [
  	"Stephen King",

 ],
 "publisher" => "Viking Press",
 "isbn" => "9781501142970",

]; 

  $catalog[104] = [ 
  "title" => "Sula",
  "img" => "../img/media/sula.jpg",
  "genre" => "African-American Literature",
  "format" => "Paperback",
  "year" => "1973",
  "category" => "Books",
  "authors" => [
  	"Toni Morrison",

 ],
 "publisher" => "Alfred A. Knopf",
 "isbn" => "9781400033430",

]; 





//Movies*
$catalog[201] = [
   "title" => "Avengers: Age of Ultron",
   "img" => "../img/media/age-of-ultron.jpg",
   "genre" => "Action",
   "format" => "DVD",
   "year" => "2015",
   "category" => "Movies",
   "director" => "Joss Whedon",
   "writers" => [
       "Joss Whedon",
       "Stan Lee"

   ],
   "stars" => [
       "Chris Evans",
       "Robert Downey Jr",
       "Chris Hemsworth"
   ]

];

$catalog[202] = [
   "title" => "Black Panther",
   "img" => "../img/media/black-panther.jpg",
   "genre" => "Action",
   "format" => "DVD",
   "year" => "2018",
   "category" => "Movies",
   "director" => "Ryan Coogler",
   "writers" => [
       "Evan Narcisse",
       "Joe Robert Cole",
       "Jack Kirby"

   ],
   "stars" => [
       "Chadwick Boseman",
       "Michael B. Jordan",
       "Lupita Nyong'o",
       "Danai Gurira"
   ]
   
];

$catalog[203] = [
   "title" => "The Dark Knight",
   "img" => "../img/media/dark-knight.jpg",
   "genre" => "Drama/Crime",
   "format" => "DVD",
   "year" => "2008",
   "category" => "Movies",
   "director" => "Christopher Nolan",
   "writers" => [
       "Jonathan Nolan",
       "David S. Goyer",

   ],
   "stars" => [
       "Christian Bale",
       "Heath Ledger",
       "Gary Oldman"
   ]
   
];

$catalog[204] = [
   "title" => "Reservoir Dogs",
   "img" => "../img/media/reservoir-dogs.jpg",
   "genre" => "Crime Film/Thriller",
   "format" => "DVD",
   "year" => "1992",
   "category" => "Movies",
   "director" => "Quentin Tarantino",
   "writers" => [
       "Quentin Tarantino",
       "Roger Avary"

   ],
   "stars" => [
       "Tim Roth",
       "Steve Buscemi",
       "Harvey Keitel",
       "Michael Madsen"
   ]
   
];

//Music*

$catalog[301] = [
   "title" => "Badlands",
   "img" => "../img/media/badlands.jpg",
   "genre" => "ElectroPop",
   "format" => "CD",
   "year" => "2015",
   "category" => "Music",
   "artist" => "Halsey",
]; 

$catalog[302] = [
   "title" => "Channel Orange",
   "img" => "../img/media/channel-orange.jpg",
   "genre" => "Contemporary R&B",
   "format" => "CD",
   "year" => "2012",
   "category" => "Music",
   "artist" => "Frank Ocean",
]; 

$catalog[303] = [
   "title" => "Get Lifted",
   "img" => "../img/media/get-lifted.jpg",
   "genre" => "R&B",
   "format" => "CD",
   "year" => "2004",
   "category" => "Music",
   "artist" => "John Legend",
]; 

$catalog[304] = [
   "title" => "To Pimp A Buttefly",
   "img" => "../img/media/tpab.jpg",
   "genre" => "Rap",
   "format" => "CD",
   "year" => "2015",
   "category" => "Music",
   "artist" => "Kendrick Lamar",
]; 
?>